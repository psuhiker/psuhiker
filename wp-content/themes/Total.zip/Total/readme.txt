Dear customer, First of all, thank you for your purchase!

If you happen to face some difficulties with this theme, consider to use our support which is conducted through our site: http://wpexplorer-themes.com/support/

Don’t forget to first read through the Documentation (link below) before asking questions, it saves us both a lot of time! 

===

THEME DOCS:

http://wpexplorer-themes.com/total/docs/


===

LEGAL:

Symple Workz LLC. shall not be held liable for any damages, including, but not limited to, the loss of data or profit, arising from the use of, or inability to use, this product.


====

Thank you,
AJ Clarke

All the best and have a nice day