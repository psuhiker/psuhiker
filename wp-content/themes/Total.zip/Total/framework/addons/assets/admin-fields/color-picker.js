( function( $ ) {
	"use strict";
	$('.wpex-color-field').wpColorPicker();
} ) ( jQuery );  